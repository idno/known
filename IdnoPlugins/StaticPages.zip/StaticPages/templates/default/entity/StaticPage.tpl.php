
    <div style="margin-top: 3em">
        <?php

            if ($vars['object']->canEdit()) {

        ?>
        <p>
            <small><a href="<?=\Idno\Core\site()->config()->getURL()?>admin/staticpages/">Pages admin</a></small>
        </p>
        <?php

            }

        ?>
        <h1 class="p-name" style="margin-bottom: 1em"><a href="<?=$vars['object']->getURL()?>"><?=$vars['object']->getTitle()?></a></h1>
        <?php

            if (!empty($vars['object']->forward_url)) {

                ?>
                <h2>
                    You are seeing this page because you are a site administrator. Other users will be forwarded
                    to <a href="<?=$vars['object']->forward_url?>"><?=$vars['object']->forward_url?></a>.
                </h2>
                <?php

            }

        ?>
        <?php echo $this->autop($this->parseURLs($this->parseHashtags($vars['object']->body),$rel)); ?>
    </div>
    <div style="margin-top: 5em">
        <?= $this->draw('content/edit') ?>
    </div>