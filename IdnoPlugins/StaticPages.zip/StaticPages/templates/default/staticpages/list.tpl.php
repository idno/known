<div style="margin-top: 3em; text-align: center">

    <?php

        if ($staticpages = \Idno\Core\site()->plugins()->get('StaticPages')) {
            /* @var \IdnoPlugins\StaticPages\Main $staticpages */
            if ($pages_list = $staticpages->getPagesAndCategories()) {

                foreach($pages_list as $category => $pages) {

                    if (!empty($pages) || substr($category, 0, 1) == '#') {
                        echo '<div style="display: inline-block; width: 150px; text-align: left; vertical-align: top">';
                        if (substr($category, 0, 1) == '#') {
                            echo '<p><a href="'.\Idno\Core\site()->config()->getURL().'content/all/?q='.urlencode($category).'"><strong>'.$category.'</strong></a></p>';
                        } else {
                            echo '<p><strong>'.$category.'</strong></p>';
                        }
                        if (!empty($pages)) {
                            foreach($pages as $page) {
                                echo '<p><a href="'.$page->getURL().'">'.$page->getTitle().'</a></p>';
                            }
                        }
                        echo '</div>';
                    }

                }

            }
        }
    ?>

</div>