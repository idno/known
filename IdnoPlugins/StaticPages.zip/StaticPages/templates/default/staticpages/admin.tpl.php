<div class="row">
    <div class="span10 offset1">
        <?=$this->draw('admin/menu')?>
        <h1>
            Pages
        </h1>
        <p class="explanation">
            Create categorized static pages to inform your site users and provide general information.
        </p>

    </div>
</div>
<div class="row">

    <div class="span10 offset1">

        <?php

            if (empty($vars['categories'])) {

                ?>
                <h2>
                    Categories
                </h2>
                <p>
                    You need to add categories before you can add a new page. To get started, just add one
                    per line.
                </p>
        <?php
                echo $this->draw('staticpages/admin/categories');

            } else {

                ?>
                <div id="categories" style="display:none"><?=$this->draw('staticpages/admin/categories')?></div>
                <p><small><a href="#" onclick="$('#categories').slideDown(); return false;">+ Edit categories</a></small></p>
                <?php

                foreach($vars['pages'] as $category => $pages) {

                    ?>

                    <h3><?=$category?></h3>
                    <p>
                        <small><a href="<?=\Idno\Core\site()->config()->getURL()?>staticpages/edit/?category=<?=urlencode($category)?>">+ Add a page</a></small>
                    </p>
                    <?php

                    if (!empty($pages)) {
                        foreach($pages as $page) {

                            ?>
                            <p>
                                <a href="<?=$page->getURL()?>"><?=htmlspecialchars($page->getTitle())?></a>
                            </p>
                        <?php

                        }
                    }

                }

            }

        ?>

    </div>

</div>